package com.example.ghbrowser

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var addressBar: EditText
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(15, 17, 22))
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(Color.rgb(25, 28, 35))
        }

        fun button(text: String): Button = Button(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(45, 49, 60))
        }

        val back = button("‹")
        val forward = button("›")
        val reload = button("↻")
        val go = button("GO")

        addressBar = EditText(this).apply {
            hint = "Enter URL or search"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setBackgroundColor(Color.rgb(35, 39, 48))
            imeOptions = EditorInfo.IME_ACTION_GO
        }

        toolbar.addView(back, LinearLayout.LayoutParams(48, 52))
        toolbar.addView(forward, LinearLayout.LayoutParams(48, 52))
        toolbar.addView(reload, LinearLayout.LayoutParams(48, 52))
        toolbar.addView(addressBar, LinearLayout.LayoutParams(0, 52, 1f).apply {
            setMargins(6, 0, 6, 0)
        })
        toolbar.addView(go, LinearLayout.LayoutParams(58, 52))

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportMultipleWindows(false)
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            settings.userAgentString = settings.userAgentString + " GitHubBrowser/1.0"

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false

                override fun onPageFinished(view: WebView, url: String) {
                    addressBar.setText(url)
                    addressBar.setSelection(addressBar.text.length)
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progressBar.progress = newProgress
                    progressBar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
                }
            }
        }

        root.addView(toolbar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 68))
        root.addView(progressBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 4))
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val open = { openAddress() }
        go.setOnClickListener { open() }
        addressBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)) {
                open()
                true
            } else false
        }
        back.setOnClickListener { if (webView.canGoBack()) webView.goBack() }
        forward.setOnClickListener { if (webView.canGoForward()) webView.goForward() }
        reload.setOnClickListener { webView.reload() }

        webView.loadUrl("https://github.com/")
    }

    private fun openAddress() {
        var input = addressBar.text.toString().trim()
        if (input.isEmpty()) return

        if (!input.contains(" ") &&
            (input.startsWith("http://") || input.startsWith("https://"))) {
            webView.loadUrl(input)
            return
        }

        if (!input.contains(" ") && input.contains(".") && !input.startsWith("www.")) {
            input = "https://$input"
        } else if (!input.contains(" ") && input.startsWith("www.")) {
            input = "https://$input"
        } else {
            input = "https://www.google.com/search?q=" +
                java.net.URLEncoder.encode(input, "UTF-8")
        }

        webView.loadUrl(input)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }
}
