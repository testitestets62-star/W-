# GitHub Browser — Build Fix

This package fixes the GitHub Actions error:

`No file ... matched to [**/*.gradle*, **/gradle-wrapper.properties, ...]`

The workflow does **not** use `gradle/actions/setup-gradle`, so a Gradle Wrapper is not required.
GitHub Actions downloads Gradle 8.7 directly and builds the Android project.

## Important
Keep only this workflow in `.github/workflows/`.

If your GitHub repository already contains another old workflow that uses
`gradle/actions/setup-gradle` or expects `gradle-wrapper.properties`, delete that
old workflow. Otherwise GitHub may run both workflows.

## Build
The successful run creates:

`app/build/outputs/apk/debug/app-debug.apk`

and uploads it as the artifact:

`GitHubBrowser-debug-apk`
